# -*- coding: utf-8 -*-
#author Zhaolang 2015-06-05
from pyokapi import get, api
import flight_query
@get("/flightzl")
def flightzl():
	dc = api.args.get('depart_city')
	ac = api.args.get('arrival_city')
	t = api.args.get('time')
	return flight_query.flight_query(dc,ac,t)