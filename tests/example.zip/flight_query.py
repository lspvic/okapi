# -*- coding: utf-8 -*-
#author Zhaolang 2015-03-12
import requests
import json
import time


#来自携程网
#"searchitem":[{"dccode":"BJS","accode":"SHA","dtime":"/Date(1426694400000-0000)/"}],
#查询仅需要json中的searchitem的内容，由起止城市的三字码及时间戳组成
#城市三字码，查询时使用
city_code = {u'安康市':'AKA',
         u'阿克苏市':'AKU',
         u'安庆市':'AQG',
         u'安阳市':'AYN',
         u'包头市':'BAV',
         u'北海市':'BHY',
         u'北京市':'BJS',
         u'昌都市':'BPX',
         u'保山市':'BSD',
         u'广州市':'CAN',
         u'常德市':'CGD',
         u'郑州市':'CGO',
         u'长春市':'CGQ',
         u'朝阳市':'CHG',
         u'酒泉市':'CHW',
         u'赤峰市':'CIF',
         u'长治市':'CIH',
         u'重庆市':'CKG',
         u'长海市':'CNI',
         u'长沙市':'CSX',
         u'成都市':'CTU',
         u'常州市':'CZX',
         u'大同市':'DAT',
         u'达州市':'DAX',
         u'丹东市':'DDG',
         u'香格里拉':'DIG',
         u'大连市':'DLC',
         u'大理市':'DLU',
         u'敦煌市':'DNH',
         u'东营市':'DOY',
         u'张家界市':'DYG',
         u'恩施市':'ENH',
         u'延安市':'ENY',
         u'阜阳市':'FIG',
         u'福州市':'FOC',
         u'富蕴市':'FYN ',
         u'广汉市':'GHN',
         u'格尔木市':'GOQ',
         u'海口市':'HAK',
         u'黑河市':'HEK',
         u'呼和浩特市':'HET',
         u'合肥市':'HFE',
         u'杭州市':'HGH',
         u'怀化市':'HJJ',
         u'海拉尔市':'HLD',
         u'乌兰浩特市':'HLH',
         u'哈密市':'HMI',
         u'衡阳市':'HNY',
         u'哈尔滨市':'HRB',
         u'舟山市':'HSN',
         u'和田市':'HTN',
         u'黄岩市':'HYN',
         u'汉中市':'HZG',
         u'银川市':'INC',
         u'且末市':'IQM',
         u'庆阳市':'IQN',
         u'景德镇市':'JDZ',
         u'嘉峪关市':'JGN',
         u'井冈山市':'JGS',
         u'西双版纳市':'JHG',
         u'吉林市':'JIL',
         u'九江市':'JIU',
         u'泉州市':'JJN',
         u'佳木斯市':'JMU',
         u'锦州市':'JNZ',
         u'衢州市':'JUZ',
         u'九寨沟':'JZH',
         u'库车市':'KCA',
         u'喀什市':'KHG',
         u'南昌市':'KHN',
         u'昆明市':'KMG',
         u'赣州市':'KOW',
         u'库尔勒市':'KRL',
         u'克拉玛依市':'KRY',
         u'贵阳市':'KWE',
         u'桂林市':'KWL',
         u'连城市':'LCX',
         u'兰州市':'LHW',
         u'丽江市':'LJG',
         u'临沧市':'LNJ',
         u'潞西市':'LUM',
         u'拉萨市':'LXA',
         u'洛阳市':'LYA',
         u'连云港市':'LYG',
         u'临沂市':'LYI',
         u'柳州市':'LZH',
         u'泸州市':'LZO',
         u'牡丹江市':'MDG',
         u'绵阳市':'MIG',
         u'梅州市':'MXZ',
         u'南充市':'NAO',
         u'齐齐哈尔市':'NDG',
         u'宁波市':'NGB',
         u'南京市':'NKG',
         u'南宁市':'NNG',
         u'南阳市':'NNY',
         u'南通市':'NTG',
         u'攀枝花':'PZI',
         u'上海市':'SHA',
         u'沈阳市':'SHE',
         u'山海关市':'SHP',
         u'荆州市':'SHS',
         u'石家庄市':'SJW',
         u'汕头市':'SWA',
         u'思茅市':'SYM',
         u'三亚市':'SYX',
         u'深圳市':'SZX',
         u'青岛市':'TAO',
         u'塔城市':'TCG',
         u'铜仁市':'TEN',
         u'通辽市':'TGO',
         u'济南市':'TNA',
         u'通化':'TNH',
         u'天津市':'TSN',
         u'黄山市':'TXN',
         u'太原市':'TYN',
         u'乌鲁木齐市':'URC',
         u'榆林市':'UYN',
         u'潍坊市':'WEF',
         u'威海市':'WEH',
         u'温州市':'WNZ',
         u'乌海市':'WUA',
         u'武汉市':'WUH',
         u'武夷山市':'WUS',
         u'无锡市':'WUX',
         u'梧州市':'WUZ',
         u'万县市':'WXN',
         u'襄樊市':'XFN',
         u'西昌市':'XIC',
         u'锡林浩特市':'XIL',
         u'西安市':'SIA',
         u'厦门市':'XMN',
         u'西宁市':'XNN',
         u'徐州市':'XUZ',
         u'宜宾市':'YBP',
         u'盐城市':'YHZ',
         u'宜昌市':'YIH',
         u'伊宁市':'YIN',
         u'义乌市':'YIW',
         u'延吉市':'YNJ',
         u'烟台市':'YNT',
         u'昭通市':'ZAT',
         u'湛江市':'ZHA',
         u'珠海市':'ZUH',
         u'遵义市':'ZYI',
}

def flight_query(dep_city,arr_city,dep_time):
    #dep_city = api.args.get('dc')
    #arr_city = api.args.get('ac')
    #dep_time = api.args.get('t')
    url = 'http://m.ctrip.com/restapi/soa2/10400/Flight/Domestic/ListV2/Search'
    jdata = {"tabtype":1,
             "ver":0,
             "tripType":1,
             "ticketIssueCty":"BJS",
             "flag":0,"pageIdx":1,
             "passengerType":1,
             "items":[{"dCtyCode":"BJS","dCtyId":1,"dcityName":"北京","dkey":3,"aCtyCode":"SHA","aCtyId":2,"acityName":"上海","akey":2,"date":"2015/03/19"}],
             "_items":[{"dCtyCode":"BJS","dCtyId":1,"dcityName":"北京","dkey":3,"aCtyCode":"SHA","aCtyId":2,"acityName":"上海","akey":2,"date":"2015/03/19"}],
             "class":0,
             "depart-sorttype":"time",
             "depart-orderby":"asc",
             "arrive-sorttype":"time",
             "arrive-orderby":"asc",
             "calendarendtime":"2015/08/16 10:02:52",
             "submittime":1426556447650,
             "fullCabin":False,
             "dScrollTop":0,
             "aScrollTop":0,
             "triptype":1,
             "trptpe":1,
             "searchitem":[{"dccode":"HGH","accode":"CKG","dtime":"/Date(1426694400000-0000)/"}],#只有这条查询时有用
             "seat":0,
             "params":[],
             "cabinflag":0,
             "RequestId":"SHT/T^P#)*.;$,8\u0019\u0010\t",
             "head":{"cid":"09031068110002166182","ctok":"","cver":"1.0","lang":"01","sid":"8888","syscode":"09","auth":""}
            }

    dep_city = dep_city + u'市'
    arr_city = arr_city + u'市'
   
    dep_city = city_code[dep_city]
    arr_city = city_code[arr_city]

    dep_time = time.mktime(time.strptime(dep_time,'%Y-%m-%d'))
    dep_time = str(dep_time)[:-2]
   
    jdata["searchitem"][0]["dccode"] = dep_city
    jdata["searchitem"][0]["accode"] = arr_city
    jdata["searchitem"][0]["dtime"] = "/Date(" + dep_time + "000-0000)/"
    #jdata = str(jdata)    
    the_page = requests.post(url, json=jdata).json()
    result = {'flightCnt':0,
              'flights':[],}
    result['flightCnt'] = the_page['total']

    for i in range(the_page['total']):
        result['flights'].append({})
        result['flights'][i]['flightNum'] = the_page['fltitem'][i]['mutilstn'][0]['basinfo']['flgno']
        result['flights'][i]['arr_time'] = the_page['fltitem'][i]['mutilstn'][0]['dateinfo']['adate']
        result['flights'][i]['dep_time'] = the_page['fltitem'][i]['mutilstn'][0]['dateinfo']['ddate']
        result['flights'][i]['ontimerate'] = the_page['fltitem'][i]['mutilstn'][0]['dateinfo']['prate']
        result['flights'][i]['lowprice'] = the_page['fltitem'][i]['policyinfo'][0]['tprice']
        result['flights'][i]['dep_arp'] = the_page['fltitem'][i]['mutilstn'][0]['dportinfo']['aportsname']
        result['flights'][i]['arr_arp'] = the_page['fltitem'][i]['mutilstn'][0]['aportinfo']['aportsname']
        result['flights'][i]['dep_terminal'] = the_page['fltitem'][i]['mutilstn'][0]['dportinfo']['bsname']
        result['flights'][i]['arr_terminal'] = the_page['fltitem'][i]['mutilstn'][0]['aportinfo']['bsname']
        result['flights'][i]['flightcomname'] = the_page['fltitem'][i]['mutilstn'][0]['basinfo']['airsname']
        result['flights'][i]['planetype'] = the_page['fltitem'][i]['mutilstn'][0]['craftinfo']['cname'] + the_page['fltitem'][i]['mutilstn'][0]['craftinfo']['craft']
        result['flights'][i]['dep_code'] = the_page['fltitem'][i]['mutilstn'][0]['dportinfo']['city']
        result['flights'][i]['arr_code'] = the_page['fltitem'][i]['mutilstn'][0]['aportinfo']['city']
        result['flights'][i]['logourl'] = the_page['fltitem'][i]['mutilstn'][0]['basinfo']['logourl']
        
        count = 0
        result['flights'][i]['ticketinfo'] = []
        for j in the_page['fltitem'][i]['policyinfo']:
            result['flights'][i]['ticketinfo'].append({})
            result['flights'][i]['ticketinfo'][count]['amount'] = j['quantity']
            result['flights'][i]['ticketinfo'][count]['price'] = j['tprice']
            result['flights'][i]['ticketinfo'][count]['drate'] = j['drate']
            result['flights'][i]['ticketinfo'][count]['amount'] = j['quantity']
            result['flights'][i]['ticketinfo'][count]['cabintype'] = j['classinfor'][0]['sclass']
            count = count + 1
        

    
    #print 'get ' + str(result['flightCnt']) + ' flights successfully......'
    #i = 1
    #for x in result['flights']:
    #    print 'The ',i,' record: ',x['flightNum'],' ',x['lowprice'],'RMB ',x['dep_time'],'to ',x['arr_time'],'ontimerate: ',x['ontimerate']
    #    j = 1
    #    for n in x['ticketinfo']:
    #        print ' The ',j,'th ticket has ',n['amount'],' left, the price is ',n['price']
    #        j = j + 1 
    #   i = i + 1
    return result

if __name__=="__main__":
    import sys 
    import locale
    sys.argv = map(lambda x:x.decode(locale.getpreferredencoding()), sys.argv)
    dc = sys.argv[1]
    ac = sys.argv[2]
    t = sys.argv[3]
    #print dc,ac,t
    flight_query(dc,ac,t)